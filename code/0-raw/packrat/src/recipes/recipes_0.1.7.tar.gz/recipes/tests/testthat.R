library(testthat)
library(recipes)

test_check(package = "recipes")
q("no")

