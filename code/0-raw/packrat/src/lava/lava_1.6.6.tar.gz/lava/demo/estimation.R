example(estimate)
example(constrain)
example(zigreg)
